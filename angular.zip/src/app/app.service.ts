import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IRecord, ReqObj, SearchResult } from './IRecord';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  public postSearch(obj: ReqObj): Observable<SearchResult> {

   return this.http.post<SearchResult>("https://localhost:5001/api/v1/search",obj);
  }
  
}