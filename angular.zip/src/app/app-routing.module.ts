import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OktaCallbackComponent, OktaLoginRedirectComponent } from '@okta/okta-angular';

const routes: Routes = [
  // route handler to handle login requests.
  {
    path: 'login',
    component: LoginComponent
  },
  // route handler that loads dashboard component, which has AuthGuard to validate the route.
  {
    path: "dashboard",
    component: DashboardComponent,
    canActivate: [AuthGuard],
    // child components route handlers
    children:[
      {
        path:"base",
        component: BaseComponent,
        pathMatch: "full"
      },
      // child component implementing lazy loading
      {
        path: "about",
        loadChildren: () =>
        import("./components/about/about.module").then(
          (m) => m.AboutModule
        )
      }
    ]
  },
  {
    path: "oktalogin",
    component: OktaLoginRedirectComponent
  },
  {
    path: "implicit/callback",
    component: OktaCallbackComponent
  },
  //wildcard match route handler
  {
    path: "**",
    redirectTo: "dashboard"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
