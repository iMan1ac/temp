import { AfterViewInit, Component, NgModule, OnInit, ViewChild } from '@angular/core';
import {
  UITKTableModule,
  UITKTableDataSource,
  UITKTableFeaturesModule,
  UITKPaginationModule,
  IUITKPaginationConfig,
  UITKHeadingLevel,
  UITKPaginationComponent,
  IUITKPaginationEntriesPerPage,
  IUITKColumnState,
  UITKTableSortDirective,
  IUITKPaginationEvent,
  PAGINATION_EVENTS,
  UITKTableComponent,
} from '@uitk/angular';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { IRecord, ReqObj, SearchResult } from './IRecord';
import { ApiService } from './app.service';
import { arch } from 'os';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  labelText: string = 'My Label';
  helperText: string = 'My Helper text';
  selectedValue: any;
  title = 'SearchPOC';
  records: IRecord[] = [];
  arckey_v: number = 1725725;
  oStartDt_v: string = '2000-01-17';
  oEndDt_v: string = '2012-12-17';
  currentPageSize: number = 5;
  test = new Subject();


  paginationConfig: IUITKPaginationConfig = {
    id: 'pagination-example',
    description: 'Pagination Example',
    currentPageNumber: 1,
    displayingPagesTextHeadingLevel: UITKHeadingLevel.h2,
    nextButtonLabel: '>>',
    previousButtonLabel: '<<',
  };

  entriesPerPage: IUITKPaginationEntriesPerPage = {
    pageSizeOptions: [{ value: 5, selected: true }, { value: 10 }, { value: 15 }],
  };


  countries = [
    { label: 'England', value: 'ENG' },
    { label: 'Scotland', value: 'SCOT', isSelected: true },
    { label: 'Ireland', value: 'EIR' },
    { label: 'Spain', value: 'SPN' },
    { label: 'France', value: 'FRA' },
    { label: 'Germany', value: 'GER' },
  ];

  sostat = [
    { label: 'C', value: 'C', isSelected: true },
    { label: 'H', value: 'H' },
    { label: 'V', value: 'V' }
  ]

  tableHeader = [
    { name: 'Somkey', id: 'Somkey' },
    { name: 'Arckey', id: 'Arckey' },
    { name: 'Ctckey', id: 'Ctckey' },
    { name: 'Pterms', id: 'Pterms' },
    { name: 'Ordate', id: 'Ordate' },
    { name: 'Userin', id: 'Userin' },
  ];
  dataSource: IRecord[] = []; //  new UITKTableDataSource<IRecord>([]);
  totalRecords = 0;
  @ViewChild(UITKPaginationComponent, { static: true }) uitkTablePagination!: UITKPaginationComponent;
  @ViewChild('sortTable') uitkTableSort!: UITKTableSortDirective;
  @ViewChild('rootTable') uitkTable!: UITKTableComponent<IRecord[]>;


  constructor(private api: ApiService) {

  }

  ngAfterViewInit() {
    // this.dataSource.pagination = this.uitkTablePagination;
    // this.dataSource.sort = this.uitkTableSort;
  }

  onPaginationChange(pageEvent: IUITKPaginationEvent) {
    switch (pageEvent.event) {

      case PAGINATION_EVENTS.ENTRIES_PER_PAGE:
        this.paginationConfig.totalPagesCount = Math.ceil(pageEvent.totalRecords / pageEvent.entriesPerPage);
        if (this.paginationConfig.totalPagesCount < this.paginationConfig.currentPageNumber) {
          this.paginationConfig.currentPageNumber = this.paginationConfig.totalPagesCount;
        }
        // get number of records based on entries per page value
        this.currentPageSize = pageEvent.entriesPerPage;
        this.filter(this.paginationConfig.currentPageNumber, pageEvent.entriesPerPage);
        break;
      case PAGINATION_EVENTS.PREVIOUS_PAGE:
      case PAGINATION_EVENTS.NEXT_PAGE:
      case PAGINATION_EVENTS.GO_TO_PAGE:
        // set current page number
        this.paginationConfig.currentPageNumber = pageEvent.state.currentPageNumber;
        // paginate data based on current page and entries per page value
        this.filter(this.paginationConfig.currentPageNumber, pageEvent.entriesPerPage);
        break;
    }
  }

  onSelectNextPage(event: any): void {
    console.log('onSelectNextPage', event);
  }

  onSelectPrevPage(event: any): void {
    console.log('onSelectPrevPage', event);
  }

  showSelected(event: any): void {
    console.log('showSelected', event);
  }

  onClick(): void {
    this.filter(1, 5);
  }

  onSortChange(event: IUITKColumnState): void {
    this.filter(this.paginationConfig.currentPageNumber, this.currentPageSize, event.direction.valueOf(), event.column);
  }

  // TBD :: quickie for POC, refinements are to be expected.
  filter(no: number, size: number, sort: number = 1, sortby: string = 'arckey'): void {
    console.log(this.arckey_v, this.oStartDt_v, this.oEndDt_v);
    let obj: ReqObj;
    obj = {
      arckey: this.arckey_v,
      ord_startdate: new Date(this.oStartDt_v),
      ord_enddate: new Date(this.oEndDt_v),
      sort: sort === 1 ? 'ascending' : 'descending',
      sortby: sortby == null ? 'arckey' : sortby,
      pagenumber: no,
      pagesize: size
    }
    
    this.api.postSearch(obj).subscribe((response: SearchResult) => {
      this.dataSource = [...response.searchresults];
      this.totalRecords = response.totalrecords;
    });
  }


  ngOnInit() {
  }

}