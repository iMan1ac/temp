export interface IRecord {
  somkey: string,
  arckey: string,
  ctckey: string,
  commkey: string,
  retsomkey: string,
  sono: string,
  custno: string,
  sodate: string,
  ordate: string,
  shipvia: string,
  fob: string,
  pterms: string,
  shpamt: string,
  currship: string,
  ponum: string,
  userin: string,
  cseq: string
}

export interface ReqObj {
  arckey: number,
  ord_startdate: Date,
  ord_enddate: Date,
  sort: string,
  sortby: string,
  pagenumber: number,
  pagesize: number
}

export interface SearchResult {
  searchresults: IRecord[],
  totalrecords: number
}