

import { RouterModule, Routes } from "@angular/router";
import { resolve } from "url";
import { HomeComponentComponent } from "./home-component.component";

const homeRoutes: Routes = [
    //component specific routing module to separate the concerns for modular components
    {
        path: "home",
        component: HomeComponentComponent
        // resolve: {
        //     //exampleObj: exampleDataService
        // }
    }
]

export const HomeRouterModule = RouterModule.forChild(homeRoutes);
