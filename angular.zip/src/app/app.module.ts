import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  UITKTableModule,
  UITKInputModule,
  UITKTableDataSource,
  UITKTableFeaturesModule,
  UITKPaginationModule,
  IUITKPaginationConfig,
  UITKHeadingLevel,
  UITKPaginationComponent,
  UITKDropdownModule,
  IUITKPaginationEntriesPerPage,
} from '@uitk/angular';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponentComponent } from './home-component/home-component.component';
import { LoginComponent } from './core/login/login/login.component';
import { OKTA_CONFIG } from '@okta/okta-angular';
import { environment } from 'src/environments/environment';

const oktaConfig = {
  issuer: "-the-okta-auth-url",
  clientId: "clientId",
  redirectUri: environment.oktaRedirectUrl,
  pkce: true
}
@NgModule({
  declarations: [
    AppComponent,
    HomeComponentComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    UITKTableModule, CommonModule, HttpClientModule, UITKTableFeaturesModule, UITKPaginationModule, UITKInputModule, UITKDropdownModule
  ],
  providers: [
    { provide: OKTA_CONFIG, useValue: oktaConfig },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
