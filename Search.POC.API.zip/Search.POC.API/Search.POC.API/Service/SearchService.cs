﻿using Microsoft.Extensions.Configuration;
using Search.POC.API.Domain.Context;
using Search.POC.API.Domain.Entities;
using Search.POC.API.Domain.Entities.Dto;
using Search.POC.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Search.POC.API.Service
{
    public class SearchService : IService
    {
        private PheonixDbContext _pheonixDbContext;
        private IConfiguration configuration;

        public SearchService(PheonixDbContext pheonixDbContext, IConfiguration configuration)
        {
            _pheonixDbContext = pheonixDbContext;
            this.configuration = configuration;
        }

        public IEnumerable<Somast> Search(SearchRequestDTO search)
        {
            IEnumerable<Somast> result = null;



            return result;
        }

        public void Add(SomastDto body)
        {
            IEnumerable<Somast> result = null;
            var obj = new Somast();
            obj.TimeStampValue = DateTime.Now;
            _pheonixDbContext.Add(obj);
            _pheonixDbContext.SaveChanges();

            return;
        }

        public IEnumerable<SomastDto> Get()
        {
            List<SomastDto> result = new List<SomastDto>();

            var obj = _pheonixDbContext.Somast.Where(x => true);

            obj.ToList().ForEach((x) =>
            {
                var oo = new SomastDto();
                oo.Somkeyid = x.Somkeyid;
                oo.TimeStampValue = x.TimeStampValue;
                result.Add(oo);
            });
            return result;
        }
    }
}
