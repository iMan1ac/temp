using System;
using System.Linq;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace Search.POC.API.Domain.Entities.Dto
{
    [DataContract]
    public class SomastDto
    {
        private DateTimeOffset _timeVal;
        [DataMember]
        [JsonProperty("somkeyid")]
        public int Somkeyid { get; set; }

        [DataMember]
        [JsonProperty("sono")]
        public string Sono { get; set; }

        [DataMember]
        [JsonProperty("sotype")]
        public string Sotype { get; set; }

        [DataMember]
        [JsonProperty("sostat")]
        public string Sostat { get; set; }

        [DataMember]
        [JsonProperty("custno")]
        public string Custno { get; set; }

        [DataMember]
        [JsonProperty("terr")]
        public string Terr { get; set; }

        [DataMember]
        [JsonProperty("webReference")]
        public string WebReference { get; set; }

        [DataMember]
        [JsonProperty("ponum")]
        public string Ponum { get; set; }

        [DataMember]
        [JsonProperty("source")]
        public string Source { get; set; }

        [DataMember]
        [JsonProperty("cclastFourDigits")]
        public string CclastFourDigits { get; set; }

        [DataMember]
        [JsonProperty("timeStampValue")]
        public DateTimeOffset? TimeStampValue
        {
            get => _timeVal;
            set { _timeVal = value.Value; }
        }

        [DataMember]
        [JsonProperty("datetimeInUTC")]
        public DateTime GetTimeVal
        {
            get => _timeVal.UtcDateTime;
        }

        [DataMember]
        [JsonProperty("datetimeInEST")]
        public DateTime GetTimeInEST
        {
            get
            {
                return TimeZoneInfo.ConvertTimeFromUtc(GetTimeVal, TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
            }
        }
    }
}